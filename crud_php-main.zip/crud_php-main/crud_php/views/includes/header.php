<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu Primeiro CRUD PHP</title>
    <link rel="stylesheet" href="/crud_php/public/css/style.css">
</head>
<body>
    <div class="container">
        <h1>LINGUAGEM E TÉCNICAS DE PROGRAMAÇÃO -  PHP com MySQL</h1>
        <nav>
            <a href="/crud_php/public/index.php?page=produtos">Produtos</a>
            <a href="/crud_php/public/index.php?page=categorias">Categorias</a>
        </nav>
        <hr>
