        <hr>
        <footer>
            <p>&copy; <?php echo date("Y"); ?> CRUD PHP. Todos os direitos reservados.</p>
        </footer>
    </div>
</body>
</html>
